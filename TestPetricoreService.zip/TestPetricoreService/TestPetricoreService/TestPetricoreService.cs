﻿namespace TestPetricoreService
{
    using System;
    using System.ComponentModel;
    using System.Globalization;
    using System.Reflection;
    using System.ServiceProcess;
    using System.Timers;
    using TestPetricore.Utils;
    using TestPetricore.BusinessLogic;
    using EntitiesDto;
    using BusinessLogic;
    public partial class TestPetricoreService : ServiceBase
    {
        Timer TestPetricoreInformationLoaderTimer;

        public TestPetricoreService()
        {
            InitializeComponent();
            ServiceName = "TestPetricore - Mudlogging";
        }

        public void OnDebug()
        {
            OnStart(null);
        }

        protected override void OnStart(string[] args)
        {
            InitializeCulture();
            InitializeTimers();
        }

        protected override void OnStop()
        {
        }

        internal static void InitializeCulture()
        {
            string culture = "en-US";
            System.Threading.Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(culture);
            System.Threading.Thread.CurrentThread.CurrentUICulture = new CultureInfo(culture);
        }

        private void InitializeTimers()
        {
            TestPetricoreInformationLoaderTimer = new Timer();

            TimerConfiguration(TestPetricoreInformationLoaderTimer, SystemEnumerations.Settings.TestPetricoreTime);
        }

        private void TimerConfiguration(Timer timer, SystemEnumerations.Settings parameterTimeName)
        {
            string descriptionParameter = GetSettingDescription(parameterTimeName);
            SetInterval(timer, descriptionParameter);

            switch (parameterTimeName)
            {
                case SystemEnumerations.Settings.TestPetricoreTime:
                    timer.Elapsed += TestPetricoreInformationLoaderTimer_Elapsed;
                    timer.Enabled = true;
                    break;
                default:
                    break;
            }
        }

        private void SetInterval(Timer timer, string parameterTimeName)
        {
            try
            {
                SettingBL settingsBL = new SettingBL();
                SettingDto settingDto = new SettingDto();
                settingDto.Name = parameterTimeName;
                ResponseDto<SettingDto> responseSetting = settingsBL.GetById(settingDto);

                if (responseSetting != null && responseSetting.Data != null)
                {
                    timer.Interval = Convert.ToDouble(responseSetting.Data.Value);
                }
            }
            catch (Exception ex)
            {
                timer.Interval = 60000;
            }
        }

        private static string GetSettingDescription(SystemEnumerations.Settings settingEnum)
        {
            FieldInfo fi = settingEnum.GetType().GetField(settingEnum.ToString());
            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return (attributes.Length > 0) ? attributes[0].Description : settingEnum.ToString();
        }

        private void TestPetricoreInformationLoaderTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            TestPetricoreInformationLoaderTimer.Enabled = false;
            InitializeCulture();
            try
            {
                var threads = IfTaskActivated(SystemEnumerations.Settings.TestPetricoreActive);
                if (threads > 0)
                {
                    TestPetricoreServiceBL testPetricoreServiceBL = new TestPetricoreServiceBL();
                    testPetricoreServiceBL.GenerateData();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Enqueue credentials to rotate service: ", ex);
            }
            finally
            {
                TestPetricoreInformationLoaderTimer.Enabled = true;
            }
        }

        private int IfTaskActivated(SystemEnumerations.Settings settingEnum)
        {
            string descriptionParameter = GetSettingDescription(settingEnum);

            try
            {
                SettingBL settingsBL = new SettingBL();
                SettingDto settingDto = new SettingDto();
                settingDto.Name = descriptionParameter;

                ResponseDto<SettingDto> responseSetting = settingsBL.GetById(settingDto);

                if (responseSetting != null && responseSetting.Data != null)
                {
                    int value = Convert.ToInt32(responseSetting.Data.Value);
                    if (value >= 1)
                    {
                        if (value > 10)
                        {
                            value = 10;
                        }
                                                
                        return value;
                    }
                    else
                    {   
                        return value;
                    }
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {   
                return 0;
            }
        }
    }
}
