﻿namespace TestPetricore.Data
{
    using System.ComponentModel.DataAnnotations;

    public class Settings
    {
        [Key]
        [StringLength(50)]
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
