﻿namespace TestPetricore.Data
{
    using System;

    public class SampleValues
    {
        public int Id { get; set; }
        public DateTime SampleValueX { get; set; }
        public decimal SampleValueY { get; set; }
    }
}
