﻿namespace TestPetricore.Utils
{
    using System.ComponentModel;

    public class SystemEnumerations
    {
        public enum Settings
        {
            [Description("TestPetricoreActive")]
            TestPetricoreActive,
            [Description("TestPetricoreTime")]
            TestPetricoreTime
        }
    }
}
