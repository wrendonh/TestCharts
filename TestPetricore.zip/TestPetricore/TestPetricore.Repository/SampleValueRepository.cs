﻿namespace TestPetricore.Repository
{
    using Data;
    using EntitiesDto;
    using System.Collections.Generic;
    using System.Linq;
    using System;

    public class SampleValueRepository
    {
        public ResponseDto<List<SampleValuesDto>> GetAll()
        {
            ResponseDto<List<SampleValuesDto>> response = new ResponseDto<List<SampleValuesDto>>();

            using (TestPetricoreModel objEntities = new TestPetricoreModel())
            {
                IQueryable<SampleValuesDto> query = (from p in objEntities.SampleValues
                                                     select new SampleValuesDto
                                                     {
                                                         Id = p.Id,
                                                         SampleValueX = p.SampleValueX,
                                                         SampleValueY = p.SampleValueY
                                                     });

                response.Data = query.ToList();

                return response;
            }
        }

        public ResponseDto<SampleValuesDto> GetById(SampleValuesDto sampleValuesObject)
        {
            ResponseDto<SampleValuesDto> response = new ResponseDto<SampleValuesDto>();

            using (TestPetricoreModel objEntities = new TestPetricoreModel())
            {
                IQueryable<SampleValuesDto> query = (from p in objEntities.SampleValues
                                                     where p.Id == sampleValuesObject.Id
                                                     select new SampleValuesDto
                                                     {
                                                         Id = p.Id,
                                                         SampleValueX = p.SampleValueX,
                                                         SampleValueY = p.SampleValueY
                                                     });

                response.Data = query.FirstOrDefault();
                return response;
            }
        }

        public ResponseDto<SampleValuesDto> GetLast(SampleValuesDto sampleValuesObject)
        {
            ResponseDto<SampleValuesDto> response = new ResponseDto<SampleValuesDto>();

            using (TestPetricoreModel objEntities = new TestPetricoreModel())
            {
                IQueryable<SampleValuesDto> query = (from p in objEntities.SampleValues
                                                     select new SampleValuesDto
                                                     {
                                                         Id = p.Id,
                                                         SampleValueX = p.SampleValueX,
                                                         SampleValueY = p.SampleValueY
                                                     });

                var list = query.Take(sampleValuesObject.Quantity + 1).ToList();
                response.Data = list.OrderByDescending(x => x.Id).FirstOrDefault();

                return response;
            }
        }

        public ResponseDto<int> Save(SampleValuesDto sampleValuesObject)
        {
            ResponseDto<int> response = new ResponseDto<int>();

            SampleValues objSampleValue = new SampleValues
            {
                Id = sampleValuesObject.Id,
                SampleValueX = sampleValuesObject.SampleValueX,
                SampleValueY = sampleValuesObject.SampleValueY
            };

            using (TestPetricoreModel objEntities = new TestPetricoreModel())
            {
                objEntities.SampleValues.Add(objSampleValue);
                objEntities.SaveChanges();
                response.Data = objSampleValue.Id;
            }

            return response;
        }
    }
}
