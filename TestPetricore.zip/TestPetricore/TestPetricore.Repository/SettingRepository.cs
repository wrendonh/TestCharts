﻿namespace TestPetricore.Repository
{
    using Data;
    using EntitiesDto;
    using System.Collections.Generic;
    using System.Linq;
    public class SettingRepository
    {
        public ResponseDto<List<SettingDto>> GetAll()
        {
            ResponseDto<List<SettingDto>> response = new ResponseDto<List<SettingDto>>();

            using (TestPetricoreModel objEntities = new TestPetricoreModel())
            {
                IQueryable<SettingDto> query = (from p in objEntities.Setting
                                                select new SettingDto
                                                {
                                                    Name = p.Name,
                                                    Value = p.Value
                                                });

                response.Data = query.ToList();

                return response;
            }
        }

        public ResponseDto<SettingDto> GetById(SettingDto sampleValuesObject)
        {
            ResponseDto<SettingDto> response = new ResponseDto<SettingDto>();

            using (TestPetricoreModel objEntities = new TestPetricoreModel())
            {
                IQueryable<SettingDto> query = (from p in objEntities.Setting
                                                where p.Name == sampleValuesObject.Name
                                                select new SettingDto
                                                {
                                                    Name = p.Name,
                                                    Value = p.Value
                                                });

                response.Data = query.FirstOrDefault();
                return response;
            }
        }
    }
}
