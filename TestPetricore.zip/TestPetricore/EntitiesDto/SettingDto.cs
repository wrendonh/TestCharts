﻿namespace EntitiesDto
{
    public class SettingDto
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
}
