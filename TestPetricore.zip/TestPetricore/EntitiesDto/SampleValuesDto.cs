﻿using System;

namespace EntitiesDto
{
    public class SampleValuesDto
    {
        public int Id { get; set; }
        public DateTime SampleValueX { get; set; }
        public decimal SampleValueY { get; set; }

        #region Not persisted
        public int Quantity { get; set; }
        #endregion
    }
}
