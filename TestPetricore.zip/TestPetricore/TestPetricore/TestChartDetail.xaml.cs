﻿namespace TestPetricore
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for TestChartDetail.xaml
    /// </summary>
    public partial class TestChartDetail : Page
    {
        public TestChartDetail()
        {
            InitializeComponent();
        }
    }
}
