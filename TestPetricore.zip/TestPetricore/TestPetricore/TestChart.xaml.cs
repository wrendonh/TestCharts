﻿using System.Windows.Controls;

namespace TestPetricore
{
    /// <summary>
    /// Interaction logic for TestChart.xaml
    /// </summary>
    public partial class TestChart : Page
    {
        public TestChart()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            TestChartDetail testChartDetail = new TestChartDetail();
            NavigationService.Navigate(testChartDetail);
        }
    }
}
