﻿namespace TestPetricore.UserControls
{
    using BusinessLogic;
    using EntitiesDto;
    using LiveCharts;
    using LiveCharts.Configurations;
    using System;
    using System.ComponentModel;
    using System.Linq;
    using System.Windows;
    using System.Windows.Threading;

    /// <summary>
    /// Interaction logic for ConstantChangesChart.xaml
    /// </summary>
    public partial class ConstantChanges : INotifyPropertyChanged
    {
        private double axisMax;
        private double axisMin;

        public ConstantChanges()
        {
            InitializeComponent();

            var mapper = Mappers.Xy<SampleValuesDto>().X(model => model.SampleValueX.Ticks).Y(model => (double)(model.SampleValueY));

            Charting.For<SampleValuesDto>(mapper);

            ChartValues = new ChartValues<SampleValuesDto>();

            DateTimeFormatter = value => new DateTime((long)value).ToString("mm:ss");

            Quantity = 0;
            AxisStep = TimeSpan.FromSeconds(15).Ticks;
            SetAxisLimits(DateTime.Now);

            Timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(300)
            };

            Timer.Tick += TimerOnTick;
            IsDataInjectionRunning = false;
            R = new Random();

            DataContext = this;
        }

        public ChartValues<SampleValuesDto> ChartValues { get; set; }
        public Func<double, string> DateTimeFormatter { get; set; }

        public double AxisStep { get; set; }

        public double AxisMax
        {
            get { return axisMax; }
            set
            {
                axisMax = value;
                OnPropertyChanged("AxisMax");
            }
        }
        public double AxisMin
        {
            get { return axisMin; }
            set
            {
                axisMin = value;
                OnPropertyChanged("AxisMin");
            }
        }


        public int Quantity { get; set; }
        public DispatcherTimer Timer { get; set; }
        public bool IsDataInjectionRunning { get; set; }
        public Random R { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        private void RunDataOnClick(object sender, RoutedEventArgs e)
        {
            if (IsDataInjectionRunning)
            {
                Timer.Stop();
                IsDataInjectionRunning = false;
            }
            else
            {
                Timer.Start();
                IsDataInjectionRunning = true;
            }
        }

        private void TimerOnTick(object sender, EventArgs eventArgs)
        {
            SampleValuesDto sampleValuesDto = new SampleValuesDto();
            sampleValuesDto.Quantity = Quantity;

            SampleValuesBL sampleValuesBL = new SampleValuesBL();
            ResponseDto<SampleValuesDto> responseSampleValue = sampleValuesBL.GetLast(sampleValuesDto);

            if (responseSampleValue != null && responseSampleValue.Data != null)
            {
                SampleValuesDto sampleValue = responseSampleValue.Data;

                if (sampleValue != null && !ChartValues.Any(cv => cv.SampleValueX == sampleValue.SampleValueX))
                {
                    ChartValues.Add(new SampleValuesDto
                    {
                        SampleValueX = sampleValue.SampleValueX,
                        SampleValueY = sampleValue.SampleValueY
                    });

                    SetAxisLimits(sampleValue.SampleValueX);
                    Quantity = Quantity + 1;

                    //lets only use the last 30 values
                    //if (ChartValues.Count > 30)
                    //{
                    //    ChartValues.RemoveAt(0);
                    //}
                }
            }
        }

        private void SetAxisLimits(DateTime now)
        {
            AxisMax = now.Ticks + TimeSpan.FromSeconds(1).Ticks; // lets force the axis to be 100ms ahead
            AxisMin = now.Ticks - TimeSpan.FromSeconds(8).Ticks; //we only care about the last 8 seconds
        }

        protected virtual void OnPropertyChanged(string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
