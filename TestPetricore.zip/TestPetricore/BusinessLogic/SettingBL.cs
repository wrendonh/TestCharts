﻿namespace TestPetricore.BusinessLogic
{
    using System;
    using System.Collections.Generic;
    using EntitiesDto;
    using Repository;

    public class SettingBL : ISample<SettingDto>
    {
        public ResponseDto<List<SettingDto>> GetAll()
        {
            SettingRepository objRepository = new SettingRepository();
            return objRepository.GetAll();
        }

        public ResponseDto<SettingDto> GetById(SettingDto genericObject)
        {
            SettingRepository objRepository = new SettingRepository();
            return objRepository.GetById(genericObject);
        }

        public ResponseDto<SettingDto> GetLast(SettingDto genericObject)
        {
            throw new NotImplementedException();
        }
        
        public ResponseDto<int> Save(SettingDto sampleValuesObject)
        {
            throw new NotImplementedException();
        }
    }
}
