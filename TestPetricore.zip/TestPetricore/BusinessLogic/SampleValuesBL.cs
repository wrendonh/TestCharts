﻿namespace TestPetricore.BusinessLogic
{
    using EntitiesDto;
    using System.Collections.Generic;
    using Repository;
    using System;

    public class SampleValuesBL : ISample<SampleValuesDto>
    {
        public ResponseDto<List<SampleValuesDto>> GetAll()
        {
            SampleValueRepository objRepository = new SampleValueRepository();
            return objRepository.GetAll();
        }

        public ResponseDto<SampleValuesDto> GetById(SampleValuesDto genericObject)
        {
            SampleValueRepository objRepository = new SampleValueRepository();
            return objRepository.GetById(genericObject);
        }
        
        public ResponseDto<SampleValuesDto> GetLast(SampleValuesDto genericObject)
        {
            SampleValueRepository objRepository = new SampleValueRepository();
            return objRepository.GetLast(genericObject);
        }

        public ResponseDto<int> Save(SampleValuesDto genericObject)
        {
            SampleValueRepository objRepository = new SampleValueRepository();
            return objRepository.Save(genericObject);
        }
    }
}
