﻿namespace BusinessLogic
{
    using EntitiesDto;
    using System;
    using TestPetricore.BusinessLogic;
    public class TestPetricoreServiceBL
    {
        public ResponseDto<bool> GenerateData()
        {
            Random rand = new Random();
            ResponseDto<bool> response = new ResponseDto<bool>();
            SampleValuesDto sampleValuesDto = new SampleValuesDto();
            sampleValuesDto.SampleValueX = DateTime.Now;
            sampleValuesDto.SampleValueY = (decimal)rand.Next(1, 10) / 10;

            SampleValuesBL sampleValuesBL = new SampleValuesBL();
            ResponseDto<int> responseSampleValuesSave = sampleValuesBL.Save(sampleValuesDto);

            if (responseSampleValuesSave != null && responseSampleValuesSave.Data > 0)
            {
                response.Data = true;
            }

            return response;
        }
    }
}
