﻿namespace TestPetricore.BusinessLogic
{
    using EntitiesDto;
    using System.Collections.Generic;

    public interface ISample<T>
    {
        ResponseDto<List<T>> GetAll();

        ResponseDto<T> GetLast(T genericObject);

        ResponseDto<T> GetById(T genericObject);

        ResponseDto<int> Save(T genericObject);
    }
}
